Hello! Thank you for downloading our font. 

Please note that this font is for personal use only and cannot be used for commercial purposes. If you’d like to use it commercially, please purchase a license on our website at https://putracetol.com/

https://putracetol.com/product/bold-brick-logo-font/

Additionally, if you’d like to make a donation, you can do so on PayPal.
Paypal account for donation : https://www.paypal.me/putracetol


We also offer 10+ free fonts for commercial use on our Freebies page. 
https://putracetol.com/freebies/

If you have any questions, feel free to contact us at putra.designer@gmail.com

Thanks,
PutraCetol Studio